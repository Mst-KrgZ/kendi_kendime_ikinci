# example_module.py

'''This module is an example module !'''

print('Modulun adi: ', __name__ ) #__main__

# Modulu dogrudan calistirirsak , ismi __main__ dir. 
## Eger modulu baska bir modul icinde import edip, baska bir modu araciligil ile cagirirsak ismi kendi ismidir yani -> example_module.py

# __name__ fonksiyonu modulun ismini ogrenmek icin kullanilir 
# __doc__ fonksiyonu modulun dokumantasyonunu yani docstring ini yani aciklamasini gormek icin kullanilir 

def greet(name):
    '''Greets people'''
    print(f'Hello {name}!')


# greet('Aslan')

# print('Doc string of the module: ', __doc__ )


# if __name__ == '__main__' :
