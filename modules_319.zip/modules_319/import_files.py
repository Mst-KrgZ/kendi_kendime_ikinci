# import_files.py

# import new # new modulunu import ettik, new uzerinden butun fonksiyonlari kullanmaniza olanak saglar

# factorial_function = new.factorial_calculate(5)
# print('factorial of 5 :', factorial_function)


# fibonacci_function =new.fibonacci_series(10)
# print(f'fibonacci series for 10 numbers: {fibonacci_function}')

#-----------------------------------------------




# import new as nw # new modulune alias (nickname ) verdik
# # alias tanimladi iseniz ,alias ile birlikte fonksiyonlari cagirmalisiniz

# factorial_function = nw.factorial_calculate(5)
# print('factorial of 5 :', factorial_function)


# fibonacci_function =nw.fibonacci_series(10)
# print(f'fibonacci series for 10 numbers: {fibonacci_function}')



#---------------------------------------------------------


# from new import * # * -> all , hepsi demektir, butun fonksiyonlari import etmek icin kulllanilir. 

# factorial_function = factorial_calculate(5)
# print('factorial of 5 :', factorial_function)


# fibonacci_function = fibonacci_series(10)
# print(f'fibonacci series for 10 numbers: {fibonacci_function}')

# ctrl + / -> yorum short key 


#-----------------------------------------------------


# from new import factorial_calculate # * -> tek bir fonksiyonu import edebiliriz

# factorial_function = factorial_calculate(5)
# print('factorial of 5 :', factorial_function)


# -----------------------------------------------


from new import factorial_calculate, fibonacci_series # * -> birden fazla fonksyonu virgullerle ayirarak impport edebiliriz 

factorial_function = factorial_calculate(5)
print('factorial of 5 :', factorial_function)


fibonacci_function = fibonacci_series(10)
print(f'fibonacci series for 10 numbers: {fibonacci_function}')
