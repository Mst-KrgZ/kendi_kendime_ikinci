
def sum_operation(a, b):
    '''Adds two given numbers''' #  docstring # aciklama satiri 
    return a + b


print(sum_operation(3,4))

#  Mac kullanicisi iseniz python main.py yerine python3 main.py yazmalisiniz. 

print(f"Iki sayinin toplami {sum_operation(int(input('Bir sayi giriniz')), int(input('Ikinci sayiyi giriniz')))}")

