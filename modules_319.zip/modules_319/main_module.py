import example_module
example_module.greet('Ahmet')