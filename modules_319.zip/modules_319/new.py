# new.py 
# 4 * 3 * 2 * 1
def factorial_calculate(n):
    '''Calculates the factorial of a given number'''
    if n == 0 or n == 1:
        return (1)
    else:
        return ( n * factorial_calculate(n - 1)) # recursion # kendi kendini cagiran fonksiyon

# print(factorial_calculate(4))
# bu bir jupyter dosyasi olmadiindan , bir python dosyasi oldugundan print olmadan cikti alamayiz




def fibonacci_series(n):
    '''Generates the Fibonacci sequence up to the given number'''
    fibonacci_list = [0,1]
    while len(fibonacci_list) < n:
        new_element = fibonacci_list[-1] + fibonacci_list[-2]
        fibonacci_list.append(new_element)
    return fibonacci_list

# print(fibonacci_series(15))

# print(factorial_calculate(int(input('Factoriali alinacak sayiyi giriniz'))))