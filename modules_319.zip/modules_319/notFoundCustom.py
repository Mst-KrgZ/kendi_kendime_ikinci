# import custom_module

# custom_module.hello()

# yukaridaki gibi cagirdigimizda dosyayi bulamiyor ve module not  found hatasi aliyoruz, 
# boyle bir durumda , dosya dizinini pythona tanitmamiz lazim 


import sys # dosya dizinini pythona tanitmak icin sys modulunu kullanabiliriz 

custom_module_path = "C:/Users/missena/Desktop/modules_319/custom"

# macde \ ->/ bu sekilde isaret desigimine gerek yok 

sys.path.append(custom_module_path)

import custom_module

custom_module.hello()

