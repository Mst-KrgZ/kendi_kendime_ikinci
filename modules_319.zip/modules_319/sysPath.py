
# pythonin modul dosyalarini nerede aradigini gosterir 

import sys

print(sys.path)
# pythonin modul aradigi yerlerin adresleri, 